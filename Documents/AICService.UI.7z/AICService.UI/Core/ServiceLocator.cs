﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AICService.Core.Infrastructure;

namespace AICService.Core
{
    public static class ServiceLocator
    {
        // [ThreadStatic]
        private static Func<IServiceProvider> _provider;
        private static ILogger _logger = null;

        public static void Initialize(Func<IServiceProvider> provider)
        {
            _provider = provider;
        }

        public static T Resolve<T>()
        {
            return _provider().ResolveInstance<T>();
        }

        public static object Resolve(Type service)
        {
            return _provider().ResolveInstance(service);
        }

        public static IEnumerable<T> ResolveAll<T>()
        {
            return _provider().ResolveAll<T>();
        }

        public static T ResolveWithContext<T, TContext>(TContext context)
        {
            return _provider().ResolveWithContext<T, TContext>(context);

        }

        public static ILogger Logger 
        {
            get 
            {
                if (_logger == null)
                {
                    _logger = Resolve<ILogger>();
                }
                return _logger;
            }
        }
    }
}
