﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge.Controls;
using AForge.Video;
using AForge.Video.FFMPEG;
using AICService.UI.WebService;
using AICService.Video;

namespace AICService.UI
{
    public partial class MainForm : Form
    {
        private IVideoSource _previewVideoSource = null;
        private IVideoSource _archiveVideoSource = null;

        public MainForm()
        {
            InitializeComponent();
        }

        public IpCamServiceClient ICServiceClient { get; set; }
        public IpCamType RecCamera { get; set; }

        private void OpenVideoSource(VideoSourcePlayer player, IVideoSource source)
        {
            if (source == null)
            {
                return;
            }

            // set busy cursor
            this.Cursor = Cursors.WaitCursor;

            // close previous video source
            CloseVideoSource(player, source);

            // start new video source
            player.VideoSource = new AsyncVideoSource(source);
            player.Start();

            this.Cursor = Cursors.Default;
        }

        private void CloseVideoSource(VideoSourcePlayer player, IVideoSource source)
        {
            if (source == null)
            {
                return;
            }

            // set busy cursor
            this.Cursor = Cursors.WaitCursor;

            // stop current video source
            if (player.IsRunning)
            {
                player.SignalToStop();
            }

            // wait 2 seconds until camera stops
            for (int i = 0; (i < 50) && (player.IsRunning); i++)
            {
                Thread.Sleep(100);
            }
            if (player.IsRunning)
                player.Stop();

            player.BorderColor = Color.Black;
            this.Cursor = Cursors.Default;
        }

        private void _btnPreviewPlay_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(_tbPreviewUrl.Text))
            {
                MessageBox.Show(this, "URL is empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Uri url = new Uri(_tbPreviewUrl.Text);

            if (url.Scheme == "rtsp")
            {
                _previewVideoSource = new FFMPEGStream(url.ToString());
            }
            else if (url.Scheme == "http")
            { 
            }
            CloseVideoSource(_vsPlayer, _previewVideoSource);
            OpenVideoSource(_vsPlayer, _previewVideoSource);
            UpdateButtonsOnPreviewPage();
        }

        private void _btnPreviewStop_Click(object sender, EventArgs e)
        {
            CloseVideoSource(_vsPlayer, _previewVideoSource);
            UpdateButtonsOnPreviewPage();
        }

        private void UpdateButtonsOnPreviewPage()
        {
            _btnPreviewPlay.Enabled = !_vsPlayer.IsRunning;
            _btnPreviewStop.Enabled = _vsPlayer.IsRunning;

            _btnRecordStart.Enabled = !((RecCamera != null) && ICServiceClient.RecordStatus(RecCamera));
            _btnRecordStop.Enabled = ((RecCamera != null) && ICServiceClient.RecordStatus(RecCamera));
        }

        private void UpdateButtonsOnArchivePage()
        {
            _btnArchivePlay.Enabled = !_vsArchivePLayer.IsRunning;
            _btnArchiveStop.Enabled = _vsArchivePLayer.IsRunning;
            _dtPicker.Enabled = !_vsArchivePLayer.IsRunning;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            ICServiceClient = new IpCamServiceClient();
            _dtPicker.Value = DateTime.Now;
            UpdateButtonsOnPreviewPage();
        }

        private void _btnRecordStart_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(_tbPreviewUrl.Text))
            {
                MessageBox.Show(this, "URL is empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            RecCamera = GetIpCamTypeFromUrl(_tbPreviewUrl.Text);
            var ret = ICServiceClient.RecordStart(RecCamera);
            UpdateButtonsOnPreviewPage();
        }

        private IpCamType GetIpCamTypeFromUrl(string strUrl)
        {
            Uri url = new Uri(strUrl);

            var cam = new IpCamType
            {
                Ip = url.GetComponents(UriComponents.NormalizedHost | UriComponents.KeepDelimiter, UriFormat.SafeUnescaped),
                Prefix = url.GetComponents(UriComponents.Scheme | UriComponents.UserInfo | UriComponents.KeepDelimiter, UriFormat.SafeUnescaped),
                Args = url.GetComponents(UriComponents.Port | UriComponents.PathAndQuery | UriComponents.KeepDelimiter, UriFormat.SafeUnescaped)
            };

            return cam;
        }

        private void _btnRecordStop_Click(object sender, EventArgs e)
        {
            if (RecCamera == null)
            {
                return;
            }

            var ret = ICServiceClient.RecordStop(RecCamera);
            UpdateButtonsOnPreviewPage();
        }

        private void _btnArchivePlay_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(_tbArchiveUrl.Text))
            {
                MessageBox.Show(this, "Archive URL is empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (String.IsNullOrEmpty(_tbPreviewUrl.Text))
            {
                MessageBox.Show(this, "Camera URL is empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Uri url = new Uri(_tbArchiveUrl.Text);

            if (url.Scheme == "rtsp"
                || url.Scheme == "tcp")
            {
                _archiveVideoSource = new FFMPEGStream(url.ToString());
            }
            else if (url.Scheme == "http")
            {
            }

            CloseVideoSource(_vsArchivePLayer, _archiveVideoSource);
            OpenVideoSource(_vsArchivePLayer, _archiveVideoSource);

            var cam = GetIpCamTypeFromUrl(_tbPreviewUrl.Text);

            var param = new VideoStreamType
            {
                Ip = "127.0.0.1",
                Port = "1235",
                Start = _dtPicker.Value
            };
            var ret = ICServiceClient.StreamVideo(cam, param);
            UpdateButtonsOnArchivePage();
        }

        private void _btnArchiveStop_Click(object sender, EventArgs e)
        {
            CloseVideoSource(_vsArchivePLayer, _archiveVideoSource);
            UpdateButtonsOnArchivePage();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            CloseVideoSource(_vsPlayer, _previewVideoSource);
            CloseVideoSource(_vsArchivePLayer, _archiveVideoSource);

            if((RecCamera != null) && (ICServiceClient.RecordStatus(RecCamera)))
            {
                ICServiceClient.RecordStop(RecCamera);
            }

            ICServiceClient.Close();
        }
    }
}
