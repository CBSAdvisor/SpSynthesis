﻿namespace AICService.UI
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPreview = new System.Windows.Forms.TabPage();
            this._pnlView = new System.Windows.Forms.Panel();
            this._vsPlayer = new AForge.Controls.VideoSourcePlayer();
            this._pnlToolbar = new System.Windows.Forms.Panel();
            this._gbRecord = new System.Windows.Forms.GroupBox();
            this._btnRecordStop = new System.Windows.Forms.Button();
            this._btnRecordStart = new System.Windows.Forms.Button();
            this._gbPreview = new System.Windows.Forms.GroupBox();
            this._btnPreviewStop = new System.Windows.Forms.Button();
            this._btnPreviewPlay = new System.Windows.Forms.Button();
            this._tbPreviewUrl = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabArchive = new System.Windows.Forms.TabPage();
            this._pnlArchiveView = new System.Windows.Forms.Panel();
            this._vsArchivePLayer = new AForge.Controls.VideoSourcePlayer();
            this._pnlArchiveToolbar = new System.Windows.Forms.Panel();
            this._btnArchiveStop = new System.Windows.Forms.Button();
            this._btnArchivePlay = new System.Windows.Forms.Button();
            this._dtPicker = new System.Windows.Forms.DateTimePicker();
            this._tbArchiveUrl = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.tabPreview.SuspendLayout();
            this._pnlView.SuspendLayout();
            this._pnlToolbar.SuspendLayout();
            this._gbRecord.SuspendLayout();
            this._gbPreview.SuspendLayout();
            this.tabArchive.SuspendLayout();
            this._pnlArchiveView.SuspendLayout();
            this._pnlArchiveToolbar.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl.Controls.Add(this.tabPreview);
            this.tabControl.Controls.Add(this.tabArchive);
            this.tabControl.Location = new System.Drawing.Point(12, 12);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(661, 624);
            this.tabControl.TabIndex = 0;
            // 
            // tabPreview
            // 
            this.tabPreview.Controls.Add(this._pnlView);
            this.tabPreview.Controls.Add(this._pnlToolbar);
            this.tabPreview.Location = new System.Drawing.Point(4, 22);
            this.tabPreview.Name = "tabPreview";
            this.tabPreview.Padding = new System.Windows.Forms.Padding(3);
            this.tabPreview.Size = new System.Drawing.Size(653, 598);
            this.tabPreview.TabIndex = 0;
            this.tabPreview.Text = "Preview";
            this.tabPreview.UseVisualStyleBackColor = true;
            // 
            // _pnlView
            // 
            this._pnlView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this._pnlView.BackColor = System.Drawing.Color.Black;
            this._pnlView.Controls.Add(this._vsPlayer);
            this._pnlView.Location = new System.Drawing.Point(6, 112);
            this._pnlView.Name = "_pnlView";
            this._pnlView.Size = new System.Drawing.Size(640, 480);
            this._pnlView.TabIndex = 1;
            // 
            // _vsPlayer
            // 
            this._vsPlayer.BackgroundImage = global::AICService.UI.Properties.Resources.no_video;
            this._vsPlayer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this._vsPlayer.BorderColor = System.Drawing.Color.Maroon;
            this._vsPlayer.Dock = System.Windows.Forms.DockStyle.Fill;
            this._vsPlayer.ForeColor = System.Drawing.Color.White;
            this._vsPlayer.Location = new System.Drawing.Point(0, 0);
            this._vsPlayer.Name = "_vsPlayer";
            this._vsPlayer.Size = new System.Drawing.Size(640, 480);
            this._vsPlayer.TabIndex = 0;
            this._vsPlayer.Text = "videoSourcePlayer1";
            this._vsPlayer.VideoSource = null;
            // 
            // _pnlToolbar
            // 
            this._pnlToolbar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this._pnlToolbar.Controls.Add(this._gbRecord);
            this._pnlToolbar.Controls.Add(this._gbPreview);
            this._pnlToolbar.Controls.Add(this._tbPreviewUrl);
            this._pnlToolbar.Controls.Add(this.label1);
            this._pnlToolbar.Location = new System.Drawing.Point(6, 6);
            this._pnlToolbar.Name = "_pnlToolbar";
            this._pnlToolbar.Size = new System.Drawing.Size(641, 100);
            this._pnlToolbar.TabIndex = 0;
            // 
            // _gbRecord
            // 
            this._gbRecord.Controls.Add(this._btnRecordStop);
            this._gbRecord.Controls.Add(this._btnRecordStart);
            this._gbRecord.Location = new System.Drawing.Point(195, 36);
            this._gbRecord.Name = "_gbRecord";
            this._gbRecord.Size = new System.Drawing.Size(171, 52);
            this._gbRecord.TabIndex = 3;
            this._gbRecord.TabStop = false;
            this._gbRecord.Text = "Record";
            // 
            // _btnRecordStop
            // 
            this._btnRecordStop.Location = new System.Drawing.Point(87, 19);
            this._btnRecordStop.Name = "_btnRecordStop";
            this._btnRecordStop.Size = new System.Drawing.Size(75, 23);
            this._btnRecordStop.TabIndex = 1;
            this._btnRecordStop.Text = "Stop";
            this._btnRecordStop.UseVisualStyleBackColor = true;
            this._btnRecordStop.Click += new System.EventHandler(this._btnRecordStop_Click);
            // 
            // _btnRecordStart
            // 
            this._btnRecordStart.Location = new System.Drawing.Point(6, 19);
            this._btnRecordStart.Name = "_btnRecordStart";
            this._btnRecordStart.Size = new System.Drawing.Size(75, 23);
            this._btnRecordStart.TabIndex = 0;
            this._btnRecordStart.Text = "Start";
            this._btnRecordStart.UseVisualStyleBackColor = true;
            this._btnRecordStart.Click += new System.EventHandler(this._btnRecordStart_Click);
            // 
            // _gbPreview
            // 
            this._gbPreview.Controls.Add(this._btnPreviewStop);
            this._gbPreview.Controls.Add(this._btnPreviewPlay);
            this._gbPreview.Location = new System.Drawing.Point(18, 36);
            this._gbPreview.Name = "_gbPreview";
            this._gbPreview.Size = new System.Drawing.Size(171, 52);
            this._gbPreview.TabIndex = 2;
            this._gbPreview.TabStop = false;
            this._gbPreview.Text = "Preview";
            // 
            // _btnPreviewStop
            // 
            this._btnPreviewStop.Location = new System.Drawing.Point(87, 19);
            this._btnPreviewStop.Name = "_btnPreviewStop";
            this._btnPreviewStop.Size = new System.Drawing.Size(75, 23);
            this._btnPreviewStop.TabIndex = 1;
            this._btnPreviewStop.Text = "Stop";
            this._btnPreviewStop.UseVisualStyleBackColor = true;
            this._btnPreviewStop.Click += new System.EventHandler(this._btnPreviewStop_Click);
            // 
            // _btnPreviewPlay
            // 
            this._btnPreviewPlay.Location = new System.Drawing.Point(6, 19);
            this._btnPreviewPlay.Name = "_btnPreviewPlay";
            this._btnPreviewPlay.Size = new System.Drawing.Size(75, 23);
            this._btnPreviewPlay.TabIndex = 0;
            this._btnPreviewPlay.Text = "Play";
            this._btnPreviewPlay.UseVisualStyleBackColor = true;
            this._btnPreviewPlay.Click += new System.EventHandler(this._btnPreviewPlay_Click);
            // 
            // _tbPreviewUrl
            // 
            this._tbPreviewUrl.Location = new System.Drawing.Point(53, 10);
            this._tbPreviewUrl.Name = "_tbPreviewUrl";
            this._tbPreviewUrl.Size = new System.Drawing.Size(573, 20);
            this._tbPreviewUrl.TabIndex = 1;
            this._tbPreviewUrl.Text = "rtsp://admin:speech@192.168.21.138:554/axis-media/media.amp?videocodec=h264&strea" +
    "mprofile=Quality";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(15, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "URL";
            // 
            // tabArchive
            // 
            this.tabArchive.Controls.Add(this._pnlArchiveView);
            this.tabArchive.Controls.Add(this._pnlArchiveToolbar);
            this.tabArchive.Location = new System.Drawing.Point(4, 22);
            this.tabArchive.Name = "tabArchive";
            this.tabArchive.Padding = new System.Windows.Forms.Padding(3);
            this.tabArchive.Size = new System.Drawing.Size(653, 598);
            this.tabArchive.TabIndex = 1;
            this.tabArchive.Text = "Archive";
            this.tabArchive.UseVisualStyleBackColor = true;
            // 
            // _pnlArchiveView
            // 
            this._pnlArchiveView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this._pnlArchiveView.BackColor = System.Drawing.Color.Black;
            this._pnlArchiveView.Controls.Add(this._vsArchivePLayer);
            this._pnlArchiveView.Location = new System.Drawing.Point(6, 112);
            this._pnlArchiveView.Name = "_pnlArchiveView";
            this._pnlArchiveView.Size = new System.Drawing.Size(640, 480);
            this._pnlArchiveView.TabIndex = 1;
            // 
            // _vsArchivePLayer
            // 
            this._vsArchivePLayer.BackgroundImage = global::AICService.UI.Properties.Resources.no_video;
            this._vsArchivePLayer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this._vsArchivePLayer.BorderColor = System.Drawing.Color.Maroon;
            this._vsArchivePLayer.Dock = System.Windows.Forms.DockStyle.Fill;
            this._vsArchivePLayer.ForeColor = System.Drawing.Color.White;
            this._vsArchivePLayer.Location = new System.Drawing.Point(0, 0);
            this._vsArchivePLayer.Name = "_vsArchivePLayer";
            this._vsArchivePLayer.Size = new System.Drawing.Size(640, 480);
            this._vsArchivePLayer.TabIndex = 1;
            this._vsArchivePLayer.Text = "videoSourcePlayer1";
            this._vsArchivePLayer.VideoSource = null;
            // 
            // _pnlArchiveToolbar
            // 
            this._pnlArchiveToolbar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this._pnlArchiveToolbar.Controls.Add(this._btnArchiveStop);
            this._pnlArchiveToolbar.Controls.Add(this._btnArchivePlay);
            this._pnlArchiveToolbar.Controls.Add(this._dtPicker);
            this._pnlArchiveToolbar.Controls.Add(this._tbArchiveUrl);
            this._pnlArchiveToolbar.Controls.Add(this.label2);
            this._pnlArchiveToolbar.Location = new System.Drawing.Point(6, 6);
            this._pnlArchiveToolbar.Name = "_pnlArchiveToolbar";
            this._pnlArchiveToolbar.Size = new System.Drawing.Size(641, 100);
            this._pnlArchiveToolbar.TabIndex = 0;
            // 
            // _btnArchiveStop
            // 
            this._btnArchiveStop.Location = new System.Drawing.Point(347, 40);
            this._btnArchiveStop.Name = "_btnArchiveStop";
            this._btnArchiveStop.Size = new System.Drawing.Size(75, 23);
            this._btnArchiveStop.TabIndex = 6;
            this._btnArchiveStop.Text = "Stop";
            this._btnArchiveStop.UseVisualStyleBackColor = true;
            this._btnArchiveStop.Click += new System.EventHandler(this._btnArchiveStop_Click);
            // 
            // _btnArchivePlay
            // 
            this._btnArchivePlay.Location = new System.Drawing.Point(266, 40);
            this._btnArchivePlay.Name = "_btnArchivePlay";
            this._btnArchivePlay.Size = new System.Drawing.Size(75, 23);
            this._btnArchivePlay.TabIndex = 5;
            this._btnArchivePlay.Text = "Play";
            this._btnArchivePlay.UseVisualStyleBackColor = true;
            this._btnArchivePlay.Click += new System.EventHandler(this._btnArchivePlay_Click);
            // 
            // _dtPicker
            // 
            this._dtPicker.CustomFormat = "dd MMMM yyyy HH:mm";
            this._dtPicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this._dtPicker.Location = new System.Drawing.Point(21, 39);
            this._dtPicker.Name = "_dtPicker";
            this._dtPicker.ShowUpDown = true;
            this._dtPicker.Size = new System.Drawing.Size(200, 20);
            this._dtPicker.TabIndex = 4;
            // 
            // _tbArchiveUrl
            // 
            this._tbArchiveUrl.Location = new System.Drawing.Point(56, 13);
            this._tbArchiveUrl.Name = "_tbArchiveUrl";
            this._tbArchiveUrl.Size = new System.Drawing.Size(573, 20);
            this._tbArchiveUrl.TabIndex = 3;
            this._tbArchiveUrl.Text = "tcp://127.0.0.1:1235?listen";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(18, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "URL";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(685, 648);
            this.Controls.Add(this.tabControl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Avidius IP Camera Service";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.tabControl.ResumeLayout(false);
            this.tabPreview.ResumeLayout(false);
            this._pnlView.ResumeLayout(false);
            this._pnlToolbar.ResumeLayout(false);
            this._pnlToolbar.PerformLayout();
            this._gbRecord.ResumeLayout(false);
            this._gbPreview.ResumeLayout(false);
            this.tabArchive.ResumeLayout(false);
            this._pnlArchiveView.ResumeLayout(false);
            this._pnlArchiveToolbar.ResumeLayout(false);
            this._pnlArchiveToolbar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPreview;
        private System.Windows.Forms.TabPage tabArchive;
        private System.Windows.Forms.Panel _pnlToolbar;
        private System.Windows.Forms.Panel _pnlView;
        private System.Windows.Forms.TextBox _tbPreviewUrl;
        private System.Windows.Forms.Label label1;
        private AForge.Controls.VideoSourcePlayer _vsPlayer;
        private System.Windows.Forms.GroupBox _gbPreview;
        private System.Windows.Forms.Button _btnPreviewStop;
        private System.Windows.Forms.Button _btnPreviewPlay;
        private System.Windows.Forms.GroupBox _gbRecord;
        private System.Windows.Forms.Button _btnRecordStop;
        private System.Windows.Forms.Button _btnRecordStart;
        private System.Windows.Forms.Panel _pnlArchiveView;
        private System.Windows.Forms.Panel _pnlArchiveToolbar;
        private System.Windows.Forms.DateTimePicker _dtPicker;
        private System.Windows.Forms.TextBox _tbArchiveUrl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button _btnArchiveStop;
        private System.Windows.Forms.Button _btnArchivePlay;
        private AForge.Controls.VideoSourcePlayer _vsArchivePLayer;
    }
}

