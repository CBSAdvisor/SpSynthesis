﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autofac;
using AICService.Core.Infrastructure;
using AICService.Infrastructure;
using AICService.Core;
using IServiceProvider = AICService.Core.IServiceProvider;
using System.Reflection;
using System.Windows.Forms;
using AICService.Infrastructure.Registration;

namespace AICService.UI
{
    public static class AppConfig
    {
        public static IContainer Container { get; private set; }

        public static void Run()
        {
            if (IsInitialized)
            {
                return;
            }

            SetupContainer();
            IsInitialized = true;
        }

        private static void SetupContainer()
        {
            ContainerBuilder builder = new ContainerBuilder();

            builder.RegisterType<Logger>().As<ILogger>();

            #region Modules

            builder.RegisterModule<DataAccessRegistrationModule>();
            builder.RegisterModule<ServicesRegistrationModule>();

            #endregion

            // Register all forms
            var assembly = Assembly.GetExecutingAssembly();
            builder.RegisterAssemblyTypes(assembly)
                .AssignableTo<Form>();

            builder.RegisterType<AutofacServiceProvider>()
                .As<AICService.Core.IServiceProvider>()
                .InstancePerLifetimeScope();

            Container = builder.Build();

            ServiceLocator.Initialize(() =>
            {
                return Container.Resolve<IServiceProvider>();
            });
        }

        public static void Dispose()
        {
            if (!IsInitialized)
            {
                return;
            }

            AppConfig.Container.Dispose();
            IsInitialized = false;
        }

        public static TForm CreateForm<TForm>() where TForm : Form
        {
            var formScope = Container.BeginLifetimeScope("FormScope");
            var form = formScope.Resolve<TForm>();
            form.Closed += (s, e) => formScope.Dispose();
            return form;
        }

        public static bool IsInitialized { get; set; }
    }
}
