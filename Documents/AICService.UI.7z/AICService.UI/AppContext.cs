﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AICService.Core;

namespace AICService.UI
{
    /// <summary>
    /// Class AppContext
    /// </summary>
    public class AppContext : ApplicationContext
    {
        //
        // Summary:
        //     Initializes a new instance of the System.Windows.Forms.ApplicationContext
        //     class with the specified System.Windows.Forms.Form.
        //
        // Parameters:
        //   mainForm:
        //     The main System.Windows.Forms.Form of the application to use for context.
        public AppContext(Form mainForm)
        { 
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AppContext" /> class.
        /// </summary>
        public AppContext()
        {
            AppConfig.Run();

            MainForm = AppConfig.CreateForm<MainForm>();

            // Handle the ApplicationExit event to know when the application is exiting.
            Application.ApplicationExit += new EventHandler(this.OnApplicationExit);
            ServiceLocator.Logger.Info("AICService started.");
        }

        /// <summary>
        /// Called when [application exit].
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="EventArgs" /> instance containing the event data.</param>
        private void OnApplicationExit(object sender, EventArgs e)
        {
            ServiceLocator.Logger.Info("AICService exited.");
            AppConfig.Dispose();
        }
    }
}
